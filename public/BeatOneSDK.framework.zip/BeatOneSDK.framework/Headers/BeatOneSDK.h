//
//  BeatOneSDK.h
//  BeatOneSDK
//
//  Created by Oscar on 1/3/21.
//

#import <Foundation/Foundation.h>

//! Project version number for BeatOneSDK.
FOUNDATION_EXPORT double BeatOneSDKVersionNumber;

//! Project version string for BeatOneSDK.
FOUNDATION_EXPORT const unsigned char BeatOneSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BeatOneSDK/PublicHeader.h>


